"use client"

import { useEffect, useState } from "react"
import { useParams } from "next/navigation"
import type { ContentTable } from "@shared/types"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle, Loader2 } from "lucide-react"

export default function VideoPage() {
  const params = useParams()
  const id = params.id as string
  const [contentTable, setContentTable] = useState<ContentTable>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchContent = async () => {
      try {
        setError(null)
        const response = await fetch(`/api/video/${id}/content`, {
          credentials: "include",
          headers: {
            Cookie: document.cookie
          }
        })
        if (!response.ok) throw new Error("Failed to fetch video content")
        const data = await response.json()
        setContentTable(data)
      } catch (error) {
        console.error("Error fetching content:", error)
        setError(error instanceof Error ? error.message : "An error occurred while loading the video content")
      } finally {
        setIsLoading(false)
      }
    }

    if (id) {
      fetchContent()
    }
  }, [id])

  if (isLoading) {
    return (
      <div className="container mx-auto py-8 px-4 flex items-center justify-center min-h-[50vh]">
        <div className="flex items-center gap-2">
          <Loader2 className="h-6 w-6 animate-spin" />
          <p>Loading video content...</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="container mx-auto py-8 px-4">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Video Player Column */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Video Player</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="aspect-video bg-muted rounded-lg">
                <iframe
                  width="100%"
                  height="100%"
                  src={`https://www.youtube.com/embed/${id}`}
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                ></iframe>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Content and Notes Column */}
        <div className="lg:col-span-1">
          <Tabs defaultValue="chapters">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="chapters">Chapters</TabsTrigger>
              <TabsTrigger value="transcript">Transcript</TabsTrigger>
            </TabsList>
            <TabsContent value="chapters">
              <Card>
                <CardContent className="p-4">
                  <ScrollArea className="h-[600px]">
                    {contentTable.length === 0 ? (
                      <p className="text-muted-foreground text-center py-4">No chapters available yet</p>
                    ) : (
                      contentTable.map((chapter, index) => (
                        <div key={index} className="mb-4">
                          <h3 className="text-lg font-semibold mb-2">{chapter.chapter}</h3>
                          <p className="text-sm text-muted-foreground">{chapter.summary}</p>
                        </div>
                      ))
                    )}
                  </ScrollArea>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="transcript">
              <Card>
                <CardContent className="p-4">
                  <ScrollArea className="h-[600px]">
                    {contentTable.length === 0 ? (
                      <p className="text-muted-foreground text-center py-4">No transcript available yet</p>
                    ) : (
                      contentTable.map((chapter) => (
                        chapter.transcript.map((item, index) => (
                          <div key={index} className="mb-2 p-2 hover:bg-muted rounded">
                            <p className="text-sm">{item.text}</p>
                            <span className="text-xs text-muted-foreground">
                              {Math.floor(item.start / 60)}:{(item.start % 60).toString().padStart(2, "0")} - 
                              {Math.floor(item.end / 60)}:{(item.end % 60).toString().padStart(2, "0")}
                            </span>
                          </div>
                        ))
                      ))
                    )}
                  </ScrollArea>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
